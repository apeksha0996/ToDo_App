package com.example.project_app;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ToDoActivity extends AppCompatActivity {
    List<String> todolist;
    ArrayAdapter<String> arrayAdapter;
    ListView listview;
    EditText edittext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do);

        todolist = new ArrayList<>();
        arrayAdapter= new ArrayAdapter<>(this,R.layout.list_view_layout,todolist);
        listview=findViewById(R.id.id_list_view);
        listview.setAdapter(arrayAdapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView textView=(TextView) view;
                textView.setPaintFlags(textView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            }
        });
        edittext=findViewById(R.id.id_edit_text);
    }
    public void addItemToList(View view) {
        todolist.add(edittext.getText().toString());
        arrayAdapter.notifyDataSetChanged();

        edittext.setText("");
    }
}